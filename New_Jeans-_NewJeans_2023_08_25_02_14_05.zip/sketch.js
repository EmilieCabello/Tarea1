function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let song;
let font;
let fontSize = 32;
let yPosition = 0;
let backgroundImage;

function preload() {
  song = loadSound('newjeans_official_audio.mp3'); // Cambia 'tu_cancion.mp3' al nombre de tu archivo de música
  font = loadFont('KCC-Ganpan.otf');
  backgroundImage = loadImage('t_960x960_59e69-image_123986672.jpg'); // Cambia 'imagen.jpg' al nombre de tu imagen de fondo
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  song.play();
  song.setVolume(0.5);
  textFont(font);
  textSize(fontSize);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(0);
  image(backgroundImage, 0, 0, width, height);
  fill(0, 0, 255);

  // Ajusta el valor para controlar la velocidad de desplazamiento de la letra
  yPosition -= 0.4,5;

  // Cambia las líneas de la letra por las de tu canción
  let lyrics = [
   
    "NEW JEANS- NewJeans",
    "(Instrumental)",
    "...",
    "Look, it's a new me",
"Switched it up, who's this?",
"우릴 봐 NewJeans",
"So fresh, so clean",
"얼마나 기다렸던 날",
"드디어 time to step out",
"또 한 번 더 ready for sure",
"To have some more",
"New hair, new tee",
"NewJeans, do you see?",
"New hair, new tee",
"NewJeans, do you see?",
"New hair, new tee",
"NewJeans, do you see?",
"New hair, new tee",
"NewJeans, do you see?",
    "Make it feel like a game",
"Look at us, we go on and on again",
"We'll go on to the end",
"What we wanna do, on and on again",
"Make it feel like a game",
    "Look at us, we go on and on again",
    "We'll go on to the end",
    "What we wanna do, on and on again",
       "Look, it's a new me",
"Switched it up, who's this?",
"우릴 봐 NewJeans",
"So fresh, so clean",
    "얼마나 기다렸던 날",
"드디어 feeling's so right",
"또 한 번 더 I need to know",
"You want some more",
    "New hair, new tee",
"NewJeans, you and me",
"New hair, new tee",
"NewJeans, dyou and me",
"New hair, new tee",
"NewJeans, you and me",
"New hair, new tee",
"NewJeans, you and me",
    "  ",
    "   ",
    "  ",
    "   ",
 "  ",
    "   ",
    "  ",
    "   ",
    
    // ... Agrega más líneas de la canción aquí
  ];

  for (let i = 0; i < lyrics.length; i++) {
    let yPos = height + yPosition + i * fontSize * 1.5;
    text(lyrics[i], width / 2, yPos);
  }

  // Reiniciar la animación cuando la letra se haya movido fuera de la pantalla
  if (yPosition < -lyrics.length * fontSize * 1.5) {
    yPosition = 0;
  }
}
